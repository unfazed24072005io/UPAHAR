abstract class BrandServiceInterface{
  Future<dynamic> getSellerWiseBrandList(int sellerId);
  Future<dynamic> getList();
}