class ContactUsBody{
  String name; String email; String phone; String subject; String message;
  ContactUsBody({required this.name, required this.email, required this.phone, required this.subject, required this.message});
}