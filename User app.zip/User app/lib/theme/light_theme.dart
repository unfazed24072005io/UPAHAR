import 'package:flutter/material.dart';

ThemeData light({Color? primaryColor, Color? secondaryColor}) => ThemeData(
  fontFamily: 'TitilliumWeb',
  primaryColor: primaryColor ?? const Color(0xFFF2C048), // Updated
  brightness: Brightness.light,
  highlightColor: Colors.white,
  hintColor: const Color(0xFF9E9E9E),
  splashColor: Colors.transparent,

  colorScheme: ColorScheme.light(
    primary: const Color(0xFFF2C048),                  // Updated
    secondary: const Color(0xFFD6AA1A),                // Golden brown shade
    tertiary: const Color(0xFFF9D4A8),
    tertiaryContainer: const Color(0xFFF6E7B0),        // Lighter gold for background
    onTertiaryContainer: const Color(0xFF5F4B0B),      // Contrast dark gold
    onPrimary: const Color(0xFFFFF8E1),                // Light shade for primary text on gold
    surface: const Color(0xFFFFFCF5),                  // Warm light background
    onSecondary: secondaryColor ?? const Color(0xFFB78C00), // Rich mustard gold
    error: const Color(0xFFFF5555),
    onSecondaryContainer: const Color(0xFFFFF5E0),
    outline: const Color(0xFFB8911F),                  // Outline matching gold tone
    onTertiary: const Color(0xFF645108),               // Dark golden text
    primaryContainer: const Color(0xFFF2C048),         // Updated
    secondaryContainer: const Color(0xFFFFF4D2),       // Very light golden background
  ),

  pageTransitionsTheme: const PageTransitionsTheme(builders: {
    TargetPlatform.android: CupertinoPageTransitionsBuilder(),
    TargetPlatform.iOS: ZoomPageTransitionsBuilder(),
    TargetPlatform.fuchsia: ZoomPageTransitionsBuilder(),
  }),
);
