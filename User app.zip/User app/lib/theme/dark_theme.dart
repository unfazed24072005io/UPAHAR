import 'package:flutter/material.dart';

ThemeData dark = ThemeData(
  fontFamily: 'TitilliumWeb',
  primaryColor: const Color(0xFFF2C048), // Updated
  brightness: Brightness.dark,
  highlightColor: const Color(0xFF252525),
  hintColor: const Color(0xFFc7c7c7),
  cardColor: const Color(0xFF242424),
  scaffoldBackgroundColor: const Color(0xFF000000),
  splashColor: Colors.transparent,

  colorScheme: const ColorScheme.dark(
    primary: Color(0xFFF2C048),             // Updated
    secondary: Color(0xFFF2C048),           // Updated
    tertiary: Color(0xFFE5B92C),            // Golden variation
    tertiaryContainer: Color(0xFF7A6926),   // Darker golden brown
    surface: Color(0xFF2D2D2D),
    onPrimary: Color(0xFFFFF6DA),           // Light tone for contrast on gold
    onTertiaryContainer: Color(0xFF6D5206), // Updated for golden accent
    primaryContainer: Color(0xFFF2C048),    // Updated
    onSecondaryContainer: Color(0x912A2A2A),
    outline: Color(0xFFB8911F),             // Updated border tone
    onTertiary: Color(0xFFD4BA57),          // Softened golden
    secondaryContainer: Color(0xFF1F1F1F),  // Dark background support
  ),

  textTheme: const TextTheme(
    bodyLarge: TextStyle(color: Color(0xFFE9EEF4)),
  ),

  pageTransitionsTheme: const PageTransitionsTheme(builders: {
    TargetPlatform.android: ZoomPageTransitionsBuilder(),
    TargetPlatform.iOS: ZoomPageTransitionsBuilder(),
    TargetPlatform.fuchsia: ZoomPageTransitionsBuilder(),
  }),
);
